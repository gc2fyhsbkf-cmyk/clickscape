// Clickscape service worker — keeps the game playable offline.
// Bump VERSION whenever you change any file so phones pick up the update.
const VERSION = 'clickscape-v7.6';
const FILES = ['./', 'index.html', 'style.css?v=7.6', 'data.js?v=7.6', 'data3.js?v=7.6', 'data4.js?v=7.6', 'icons.js?v=7.6', 'game.js?v=7.6', 'systems.js?v=7.6', 'ui3.js?v=7.6', 'ext4.js?v=7.6', 'ext5.js?v=7.6', 'ext6.js?v=7.6', 'ext7.js?v=7.6', 'ext8.js?v=7.6', 'ext9.js?v=7.6', 'ext10.js?v=7.6', 'ext11.js?v=7.6', 'ext12.js?v=7.6', 'ext13.js?v=7.6', 'ext14.js?v=7.6', 'ext15.js?v=7.6', 'ext16.js?v=7.6', 'ext17.js?v=7.6', 'ext18.js?v=7.6', 'ext19.js?v=7.6',
  'manifest.webmanifest?v=7.6', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png', 'icons/apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(FILES)).catch(() => { })); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
// Always ask the network for a fresh copy (bypassing the browser's HTTP cache), fall back to the offline copy.
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(fetch(e.request, { cache: 'no-cache' }).then(r => {
    const copy = r.clone(); caches.open(VERSION).then(c => c.put(e.request, copy)); return r;
  }).catch(() => caches.match(e.request, { ignoreSearch: false }).then(m => m || caches.match(e.request, { ignoreSearch: true }))));
});
